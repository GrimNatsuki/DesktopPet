# DesktopPet
- This is a demo for Cartethyia desktop pet
- To spawn Cartethyia, simply click and run DesktopPet.exe file. You can create a shortcut for convenience.
- You can drag Cartethyia by holding left mouse button an moving your mouse.
- Exit by right clicking Cartethyia. An exit button will apear. Left click it.

PS: Cartethyia doesn't have much features/ behaviours yet. I just wanted to see if I can export the exe and if it works on other computers.